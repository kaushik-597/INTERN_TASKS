const createTaskBtn = document.getElementById('create-task-btn');
const clearTasksBtn = document.getElementById('clear-tasks-btn');
const taskList = document.getElementById('task-list');
const noTaskText = document.getElementById('no-task-text');

createTaskBtn.addEventListener('click', () => {
  const task = prompt("Enter your task:");
  if (task && task.trim()) {
    noTaskText.style.display = 'none';

    const li = document.createElement('li');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';

    const label = document.createElement('label');
    label.textContent = task;
    label.style.marginLeft = '8px';

    checkbox.addEventListener('change', () => {
      label.classList.toggle('completed', checkbox.checked);
    });

    li.appendChild(checkbox);
    li.appendChild(label);
    taskList.appendChild(li);

    clearTasksBtn.style.display = 'inline-block';
  }
});

clearTasksBtn.addEventListener('click', () => {
  taskList.innerHTML = '';
  noTaskText.style.display = 'block';
  clearTasksBtn.style.display = 'none';
});
