document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();
  let isValid = true;

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  const emailRegex = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

  document.getElementById("nameError").innerText = name ? "" : "Name is required";
  document.getElementById("emailError").innerText = emailRegex.test(email) ? "" : "Invalid email";
  document.getElementById("messageError").innerText = message ? "" : "Message is required";

  if (!name || !emailRegex.test(email) || !message) {
    isValid = false;
  }

  if (isValid) {
    document.getElementById("successMsg").innerText = "Form submitted successfully!";
  }
});
